#include "thread.h"


void mmap_mode(int fd, int num_threads);
void combine_output(ThreadData **threadData, int num_threads);
