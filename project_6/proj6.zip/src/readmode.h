#include <stdio.h>
#include <unistd.h>
#include <ctype.h>
#include <stdlib.h>

#include "thread.h"

void read_mode(int fd, int chunk_size);