#ifndef CONFIG_H
#define CONFIG_H

#define MAX_THREADS 16
#define MAX_READ_SIZE 8192

#endif
